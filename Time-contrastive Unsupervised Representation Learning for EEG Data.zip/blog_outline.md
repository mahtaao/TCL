---
layout: distill
title: Sample Blog Post (HTML version)
description: Your blog post's abstract.
  Please add your abstract or summary here and not in the main body of your text. 
  Do not include math/latex or hyperlinks.
date: 2025-04-28
future: true
htmlwidgets: true
hidden: false

# Anonymize when submitting
# authors:
#   - name: Anonymous

authors:
  - name: Albert Einstein
    url: "https://en.wikipedia.org/wiki/Albert_Einstein"
    affiliations:
      name: IAS, Princeton
  - name: Boris Podolsky
    url: "https://en.wikipedia.org/wiki/Boris_Podolsky"
    affiliations:
      name: IAS, Princeton
  - name: Nathan Rosen
    url: "https://en.wikipedia.org/wiki/Nathan_Rosen"
    affiliations:
      name: IAS, Princeton

# must be the exact same name as your blogpost
bibliography: 2025-04-28-distill-example.bib  

# Add a table of contents to your post.
#   - make sure that TOC names match the actual section names
#     for hyperlinks within the post to work correctly. 
#   - please use this format rather than manually creating a markdown table of contents.
toc:
  - name: Equations
  - name: Images and Figures
    subsections:
    - name: Interactive Figures
  - name: Citations
  - name: Footnotes
  - name: Code Blocks
  - name: Diagrams
  - name: Tweets
  - name: Layouts
  - name: Other Typography?

# Below is an example of injecting additional post-specific styles.
# This is used in the 'Layouts' section of this post.
# If you use this post as a template, delete this _styles block.
_styles: >
  .fake-img {
    background: #bbb;
    border: 1px solid rgba(0, 0, 0, 0.1);
    box-shadow: 0 0px 4px rgba(0, 0, 0, 0.1);
    margin-bottom: 12px;
  }
  .fake-img p {
    font-family: monospace;
    color: white;
    text-align: left;
    margin: 12px 0;
    text-align: center;
    font-size: 16px;\
  }
---

<p>
  This is a sample blog post written in HTML (while the other <a href="{% post_url 2025-04-28-distill-example %}">sample post</a> is written in Markdown). Authors have the choice to write in HTML or Markdown. While Markdown is easier to write, HTML gives you more control over the layout of your post. Furthermore, Markdown often interacts in unexpected ways with MathJax and other HTML widgets. If you are having trouble with Markdown, try writing in HTML instead.
</p>

<p>
  Note: please use the table of contents as defined in the front matter rather than the traditional markdown styling.
</p>

<h2 id="equations">Equations</h2>

<p>This theme supports rendering beautiful math in inline and display modes using <a href="https://www.mathjax.org/">MathJax 3</a> engine.
You just need to surround your math expression with <code>$$</code>, like <code>$$ E = mc^2 $$</code>.
If you leave it inside a paragraph, it will produce an inline expression, just like \(E = mc^2\).</p>

<p>To use display mode, again surround your expression with <code>$$</code> and place it as a separate paragraph.
Here is an example:
$$
\left( \sum_{k=1}^n a_k b_k \right)^2 \leq \left( \sum_{k=1}^n a_k^2 \right) \left( \sum_{k=1}^n b_k^2 \right)
$$
</p>

<p>Note that MathJax 3 is <a href="https://docs.mathjax.org/en/latest/upgrading/whats-new-3.0.html">a major re-write of MathJax</a> 
that brought a significant improvement to the loading and rendering speed, which is now 
<a href="http://www.intmath.com/cg5/katex-mathjax-comparison.php">on par with KaTeX</a>.</p>

<h2 id="images-and-figures">Images and Figures</h2>

<p>Its generally a better idea to avoid linking to images hosted elsewhere - links can break and you
might face losing important information in your blog post.
You can display images from this repository using the following code:</p>

<pre><code>{% raw %}{% include figure.html path="assets/img/2025-04-28-distill-example/iclr.png" class="img-fluid" %}{% endraw %}</code></pre>

<p>which results in the following image:</p>

{% include figure.html path="assets/img/2025-04-28-distill-example/iclr.png" class="img-fluid" %}


<p>
  To ensure that there are no namespace conflicts, you must save your asset to your unique directory
  `/assets/img/2025-04-28-[SUBMISSION NAME]` within your submission.  
</p>

<p>
  Please avoid using the direct HTML method of embedding images; they may not be properly resized.
  Some below complex ways to load images (note the different styles of the shapes/shadows):  
</p>

<div class="row mt-3">
    <div class="col-sm mt-3 mt-md-0">
        {% include figure.html path="assets/img/2025-04-28-distill-example/9.jpg" class="img-fluid rounded z-depth-1" %}
    </div>
    <div class="col-sm mt-3 mt-md-0">
        {% include figure.html path="assets/img/2025-04-28-distill-example/7.jpg" class="img-fluid rounded z-depth-1" %}
    </div>
</div>
<div class="caption">
    A simple, elegant caption looks good between image rows, after each row, or doesn't have to be there at all.
</div>

<div class="row mt-3">
    <div class="col-sm mt-3 mt-md-0">
        {% include figure.html path="assets/img/2025-04-28-distill-example/8.jpg" class="img-fluid z-depth-2" %}
    </div>
    <div class="col-sm mt-3 mt-md-0">
        {% include figure.html path="assets/img/2025-04-28-distill-example/10.jpg" class="img-fluid z-depth-2" %}
    </div>
</div>

<div class="row mt-3">
    <div class="col-sm mt-3 mt-md-0">
        {% include figure.html path="assets/img/2025-04-28-distill-example/11.jpg" class="img-fluid"  %}
    </div>
    <div class="col-sm mt-3 mt-md-0">
        {% include figure.html path="assets/img/2025-04-28-distill-example/12.jpg" class="img-fluid" %}
    </div>
    <div class="col-sm mt-3 mt-md-0">
        {% include figure.html path="assets/img/2025-04-28-distill-example/7.jpg" class="img-fluid" %}
    </div>
</div>

<h3>Interactive Figures</h3>

<p>
  Here's how you could embed interactive figures that have been exported as HTML files.
  Note that we will be using plotly for this demo, but anything built off of HTML should work.
  All that's required is for you to export your figure into HTML format, and make sure that the file
  exists in the `assets/html/[SUBMISSION NAME]/` directory in this repository's root directory.
  To embed it into any page, simply insert the following code anywhere into your page.  
</p>

<pre><code>{% raw %}{% include [FIGURE_NAME].html %}{% endraw %}</code></pre>

<p>
For example, the following code can be used to generate the figure underneath it.
</p>

<pre><code class="language-python">import pandas as pd
import plotly.express as px

df = pd.read_csv('https://raw.githubusercontent.com/plotly/datasets/master/earthquakes-23k.csv')

fig = px.density_mapbox(
    df, lat='Latitude', lon='Longitude', z='Magnitude', radius=10,
    center=dict(lat=0, lon=180), zoom=0, mapbox_style="stamen-terrain")
fig.show()

fig.write_html('./assets/html/2025-04-28-distill-example/plotly_demo_1.html')
</code></pre>

And then include it with the following:

<pre><code class="language-html">{% raw %}&lt;div class="l-page"&gt;
  &lt;iframe src="{{ 'assets/html/2025-04-28-distill-example/plotly_demo_1.html' | relative_url }}" frameborder='0' scrolling='no' height="600px" width="100%"&gt;&lt;/iframe&gt;
&lt;/div&gt;{% endraw %}
</code></pre>

Voila!

<div class="l-page">
  <iframe src="{{ 'assets/html/2025-04-28-distill-example/plotly_demo_1.html' | relative_url }}" frameborder='0' scrolling='no' height="600px" width="100%"></iframe>
</div>


<h2 id="citations">Citations</h2>


<p>
  Citations are then used in the article body with the <code>&lt;d-cite&gt;</code> tag.
    The key attribute is a reference to the id provided in the bibliography.
    The key attribute can take multiple ids, separated by commas.    
</p>

<p>
  The citation is presented inline like this: <d-cite key="gregor2015draw"></d-cite> (a number that displays more information on hover).
  If you have an appendix, a bibliography is automatically created and populated in it.  
</p>

<p>
  Distill chose a numerical inline citation style to improve readability of citation dense articles and because many of the benefits of longer citations are obviated by displaying more information on hover.
  However, we consider it good style to mention author last names if you discuss something at length and it fits into the flow well - the authors are human and it's nice for them to have the community associate them with their work.  
</p>


<h2 id="footnotes">Footnotes</h2>

<p>
  Just wrap the text you would like to show up in a footnote in a <code>&lt;d-footnote&gt;</code> tag.
    The number of the footnote will be automatically generated.<d-footnote>This will become a hoverable footnote.</d-footnote>
</p>


<h2 id="code-blocks">Code Blocks</h2>

<p>
  This theme implements a built-in Jekyll feature, the use of Rouge, for syntax highlighting.
  It supports more than 100 languages.
  This example is in C++.
  All you have to do is wrap your code in a liquid tag as follows:  
</p>

<pre><code>{% raw  %}
{% highlight c++ linenos %}  <br/> code code code <br/> {% endhighlight %}
{% endraw %}
</code></pre>

The keyword `linenos` triggers display of line numbers. You can try toggling it on or off yourself below:

{% highlight c++ %}

int main(int argc, char const *argv[])
{
string myString;

    cout &lt;&lt; "input a string: ";
    getline(cin, myString);
    int length = myString.length();

    char charArray = new char * [length];

    charArray = myString;
    for(int i = 0; i < length; ++i){
        cout &lt;&lt; charArray[i] &lt;&lt; " ";
    }

    return 0;
}

{% endhighlight %}



<h2 id="diagrams">Diagrams</h2>

<p>
  This theme supports generating various diagrams from a text description using <a href="https://github.com/zhustec/jekyll-diagrams">jekyll-diagrams</a> plugin.
  Below, we generate a few examples of such diagrams using languages such as <a href="http://mermaid.js.org/">mermaid</a>, <a href="https://plantuml.com/">plantuml</a>, <a href="https://vega.github.io/vega-lite/">vega-lite</a>, etc.  
</p>

<p>
  <b>Note</b>different diagram-generation packages require external dependencies to be installed on your machine.
  Also, be mindful of that because of diagram generation the first time you build your Jekyll website after adding new diagrams will be SLOW.
  For any other details, please refer to the <a href="https://github.com/zhustec/jekyll-diagrams">jekyll-diagrams</a> README.  
</p>

<p>
  <b>Note:</b> This is not supported for local rendering!
</p>

<p>
  The diagram below was generated by the following code:
</p>

<pre><code>{% raw %}{% mermaid %}
sequenceDiagram
    participant John
    participant Alice
    Alice->>John: Hello John, how are you?
    John-->>Alice: Great!
{% endmermaid %}
{% endraw %}
</code></pre>

{% mermaid %}
sequenceDiagram
participant John
participant Alice
Alice->>John: Hello John, how are you?
John-->>Alice: Great!
{% endmermaid %}


<h2 id="tweets">Tweets</h2>

<p>
  An example of displaying a tweet:
  {% twitter https://twitter.com/rubygems/status/518821243320287232 %}  
</p>

<p>
  An example of pulling from a timeline:
  {% twitter https://twitter.com/jekyllrb maxwidth=500 limit=3 %}  
</p>

<p>
  For more details on using the plugin visit: <a href="https://github.com/rob-murray/jekyll-twitter-plugin">jekyll-twitter-plugin</a> 
</p>


<h2 id="blockquotes">Blockquotes</h2>

<blockquote>
    We do not grow absolutely, chronologically. We grow sometimes in one dimension, and not in another, unevenly. We grow partially. We are relative. We are mature in one realm, childish in another.
    —Anais Nin
</blockquote>


<h2 id="layouts">Layouts</h2>

The main text column is referred to as the body.
It's the assumed layout of any direct descendants of the `d-article` element.

<div class="fake-img l-body">
  <p>.l-body</p>
</div>

For images you want to display a little larger, try `.l-page`:

<div class="fake-img l-page">
  <p>.l-page</p>
</div>

All of these have an outset variant if you want to poke out from the body text a little bit.
For instance:

<div class="fake-img l-body-outset">
  <p>.l-body-outset</p>
</div>

<div class="fake-img l-page-outset">
  <p>.l-page-outset</p>
</div>

Occasionally you'll want to use the full browser width.
For this, use `.l-screen`.
You can also inset the element a little from the edge of the browser by using the inset variant.

<div class="fake-img l-screen">
  <p>.l-screen</p>
</div>
<div class="fake-img l-screen-inset">
  <p>.l-screen-inset</p>
</div>

The final layout is for marginalia, asides, and footnotes.
It does not interrupt the normal flow of `.l-body`-sized text except on mobile screen sizes.

<div class="fake-img l-gutter">
  <p>.l-gutter</p>
</div>


<h2 id="other-typography">Other Typography?</h2>

<p>
  Emphasis, aka italics, with the <code>&lt;i&gt;&lt;/i&gt;</code> tag <i>emphasis</i>.
</p>

<p>
  Strong emphasis, aka bold, with <code>&lt;b&gt;&lt;/b&gt;</code> tag <b>bold</b>.
</p>

<p>
  Strikethrough ca be accomplished with the <code>&lt;s&gt;&lt;/s&gt;</code> tag. <s>Scratch this.</s>
</p>

<ul>
  <li>First ordered list item</li>
  <li>Another item</li>
  <ol>
    <li>Unordered sub-list. </li>
  </ol>
  <li>And another item.</li>
</ul>



<p>
  For code, the language can be specified in the class. For example, use <q>language-javascript</q> for Javascript and <q>language-python</q> for Python code.
</p>

<pre><code class="language-javascript">var s = "JavaScript syntax highlighting";
  alert(s);</code></pre>
 
<pre><code class="language-python">s = "Python syntax highlighting"
  print(s)</code></pre>

<pre><code class="language-python">No language indicated, so no syntax highlighting.</code></pre>

<p>
  A table can be created with the <code>&lt;table&gt;</code> element. Below is an example
</p>

<table>
  <thead>
    <tr>
      <th>Tables</th>
      <th style="text-align: center">Are</th>
      <th style="text-align: right">Cool</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>col 3 is</td>
      <td style="text-align: center">right-aligned</td>
      <td style="text-align: right">$1600</td>
    </tr>
    <tr>
      <td>col 2 is</td>
      <td style="text-align: center">centered</td>
      <td style="text-align: right">$12</td>
    </tr>
    <tr>
      <td>zebra stripes</td>
      <td style="text-align: center">are neat</td>
      <td style="text-align: right">$1</td>
    </tr>
  </tbody>
</table>


<p>
  <blockquote>Blockquotes can be defined with the &gt;blockquote&lt; tag.</blockquote>
</p>
